// myapp.c
#include <stdio.h>

int main() {
    printf("Hello from my custom Buildroot app!\n");
    return 0;
}
