#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <unistd.h>
#include <string.h>

#define I2C_BUS "1"
#define I2C_ADDR "0x68"

// MPU6050 Registers
#define PWR_MGMT_1 "0x6B"
#define PWR_WAKE "0x00"
#define WHO_AM_I "0x75"

#define ACCEL_XOUT_H 0x3B
#define ACCEL_SCALE 16384.0  // ±2g → 16384 LSB/g

// Helper to run i2cget and return uint8_t
uint8_t i2cget(const char *bus, const char *addr, const char *reg) {
    char cmd[128], result[16];
    snprintf(cmd, sizeof(cmd), "i2cget -y %s %s %s", bus, addr, reg);

    FILE *fp = popen(cmd, "r");
    if (!fp) {
        perror("popen failed");
        exit(EXIT_FAILURE);
    }

    if (!fgets(result, sizeof(result), fp)) {
        perror("fgets failed");
        pclose(fp);
        exit(EXIT_FAILURE);
    }

    pclose(fp);
    return (uint8_t)strtol(result, NULL, 0);
}

// Helper to run i2cset to write a byte
void i2cset(const char *bus, const char *addr, const char *reg, const char *value) {
    char cmd[128];
    snprintf(cmd, sizeof(cmd), "i2cset -y %s %s %s %s", bus, addr, reg, value);
    int ret = system(cmd);
    if (ret != 0) {
        fprintf(stderr, "i2cset failed for reg=%s\n", reg);
        exit(EXIT_FAILURE);
    }
}

// Read 16-bit signed value from two consecutive registers
int16_t read_word(uint8_t reg) {
    char reg_high[6], reg_low[6];
    snprintf(reg_high, sizeof(reg_high), "0x%02X", reg);
    snprintf(reg_low, sizeof(reg_low), "0x%02X", reg + 1);

    uint8_t high = i2cget(I2C_BUS, I2C_ADDR, reg_high);
    uint8_t low  = i2cget(I2C_BUS, I2C_ADDR, reg_low);

    return (int16_t)((high << 8) | low);
}

int main() {
    // Step 1: Wake up MPU6050 (write 0x00 to PWR_MGMT_1)
    i2cset(I2C_BUS, I2C_ADDR, PWR_MGMT_1, PWR_WAKE);
    usleep(10000); // 10ms delay

    // Step 2: Verify device identity
    uint8_t whoami = i2cget(I2C_BUS, I2C_ADDR, WHO_AM_I);
    if (whoami != 0x68) {
        fprintf(stderr, "Unexpected WHO_AM_I response: 0x%02X\n", whoami);
        return 1;
    }

    // Step 3: Read raw accelerometer values
    int16_t accel_x = read_word(ACCEL_XOUT_H);
    int16_t accel_y = read_word(ACCEL_XOUT_H + 2);
    int16_t accel_z = read_word(ACCEL_XOUT_H + 4);

    // Step 4: Convert to g units
    float x_g = accel_x / ACCEL_SCALE;
    float y_g = accel_y / ACCEL_SCALE;
    float z_g = accel_z / ACCEL_SCALE;

    // Step 5: Display results
    printf("MPU6050 Accelerometer (via i2cget/i2cset):\n");
    printf("X = %.2f g\n", x_g);
    printf("Y = %.2f g\n", y_g);
    printf("Z = %.2f g\n", z_g);

    return 0;
} 
